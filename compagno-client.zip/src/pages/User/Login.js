import styled from "styled-components";
import { useState } from "react";
import { asyncLogin } from "../../store/user";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";

const Div = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: calc(100vh - 100px);

  .loginInputZone {
    display: flex;
    justify-content: space-between;
    flex-direction: column;
    text-align: center;
    width: 500px;

    #headMessage {
      font-size: 3rem;
      padding-bottom: 20px;
      font-weight: bold;
    }

    input {
      margin-top: 20px;
      box-sizing: border-box;
      padding: 10px;
    }

    button {
      margin-top: 20px;
      background-color: black;
      color: white;
      padding: 10px;
      font-size: 1.2rem;
      font-weight: bold;
    }
  }
`;

const Login = () => {
  const [user, setUser] = useState({ userId: "", userPwd: "" });
  const dispatch = useDispatch();
  const navigate = useNavigate();

  // 로그인 버튼 눌렀을때
  const submit = () => {
    dispatch(asyncLogin(user));
    if (user.userId === "" || user.userId === undefined) {
      alert("아이디를 입력하세요!");
    } else if (user.userPwd === "" || user.userPwd === undefined) {
      alert("비밀번호를 입력하세요!");
    } else {
      navigate("/");
    }
  };

  return (
    <Div>
      <div className="loginInputZone">
        <div className="loginInputHead">
          <h1 id="headMessage">compagno.</h1>
        </div>
        <input
          className="idInput"
          type="text"
          placeholder="아이디"
          value={user.userId}
          onChange={(e) =>
            setUser((prev) => ({ ...prev, userId: e.target.value }))
          }
        />
        <input
          className="pwdInput"
          type="password"
          placeholder="비밀번호"
          value={user.userPwd}
          onChange={(e) =>
            setUser((prev) => ({ ...prev, userPwd: e.target.value }))
          }
        />
        <button onClick={submit}>로그인</button>
      </div>
    </Div>
  );
};
export default Login;
